create function remover_clientes_cpf_repetido() returns void
    language plpgsql
as
$$
DECLARE
    cliente_record cliente%ROWTYPE;
BEGIN
    FOR cliente_record IN
        SELECT DISTINCT ON (cpf) *
        FROM cliente
        ORDER BY cpf, -idade,
                 (SELECT COUNT(*) FROM cliente c2
                    JOIN public.veiculo v on c2.codc = v.codc
                    JOIN public.conserto c on v.codv = c.codv
                    WHERE c2.cpf = cliente_record.cpf
                    ORDER BY count(*))
    LOOP
        DELETE FROM cliente
        WHERE codc <> cliente_record.codc AND cpf = cliente_record.cpf;
    END LOOP;
END;
$$;

alter function remover_clientes_cpf_repetido() owner to guiddiel;

