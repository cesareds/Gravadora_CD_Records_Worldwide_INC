create function calcular_horas_extras(mecanico_id integer, mes integer, ano integer) returns integer
    language plpgsql
as
$$
DECLARE
    horas_trabalhadas INT;
    horas_extras INT;
BEGIN
    -- Calcular o número total de horas trabalhadas pelo mecânico em um mês
    SELECT SUM(EXTRACT(HOUR FROM hora)) INTO horas_trabalhadas
    FROM conserto
    WHERE EXTRACT(MONTH FROM data) = mes
    AND EXTRACT(YEAR FROM data) = ano
    AND codm = mecanico_id;

    -- Calcular as horas extras
    IF horas_trabalhadas > 160 THEN
        horas_extras := horas_trabalhadas - 160;
    ELSE
        horas_extras := 0;
    END IF;

    RETURN horas_extras;
END;
$$;

alter function calcular_horas_extras(integer, integer, integer) owner to guiddiel;

