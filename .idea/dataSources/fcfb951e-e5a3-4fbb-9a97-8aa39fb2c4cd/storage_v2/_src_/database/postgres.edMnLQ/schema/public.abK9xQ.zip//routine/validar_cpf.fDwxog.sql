create function validar_cpf(cpf_input character) returns boolean
    language plpgsql
as
$$
DECLARE
    cpf CHAR(11);
    soma1 INT := 0;
    soma2 INT := 0;
    resto INT;
    digito_verificador1 INT;
    digito_verificador2 INT;
BEGIN
    -- Remover qualquer caractere não numérico do CPF
    cpf := regexp_replace(cpf_input, '\D', '', 'g');

    -- Verificar se o CPF tem 11 dígitos
    IF LENGTH(cpf) <> 11 THEN
        RETURN FALSE;
    END IF;

    -- Calcular o primeiro dígito verificador
    FOR i IN 1..9 LOOP
        soma1 := soma1 + CAST(SUBSTRING(cpf FROM i FOR 1) AS INT) * (11 - i);
    END LOOP;
    resto := soma1 % 11;
    IF resto < 2 THEN
        digito_verificador1 := 0;
    ELSE
        digito_verificador1 := 11 - resto;
    END IF;

    -- Calcular o segundo dígito verificador
    FOR i IN 1..9 LOOP
        soma2 := soma2 + CAST(SUBSTRING(cpf FROM i FOR 1) AS INT) * (12 - i);
    END LOOP;
    soma2 := soma2 + digito_verificador1 * 2;
    resto := soma2 % 11;
    IF resto < 2 THEN
        digito_verificador2 := 0;
    ELSE
        digito_verificador2 := 11 - resto;
    END IF;

    -- Verificar se os dígitos verificadores do CPF fornecido correspondem aos calculados
    IF digito_verificador1 = CAST(SUBSTRING(cpf FROM 10 FOR 1) AS INT) AND
       digito_verificador2 = CAST(SUBSTRING(cpf FROM 11 FOR 1) AS INT) THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END;
$$;

alter function validar_cpf(char) owner to guiddiel;

